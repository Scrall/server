var socket = io.connect();

function addGroup(){
    var group = document.getElementById("group").value;

    socket.emit("addGroup", group);
}

function changeGroup(){
    var group = document.getElementById("group").value;
        var groupIndex = document.getElementById("groupList").selectedIndex;
            var oldGroup = document.getElementById("groupList")[groupIndex].value; 
                document.getElementById("groupList")[groupIndex].innerText = group;

    socket.emit("changeGroup", group, oldGroup);
}

function deleteGroup(){
    var groupIndex = document.getElementById("groupList").selectedIndex;
        var group = document.getElementById("groupList")[groupIndex].value; 
            document.getElementById("groupList")[groupIndex].remove();

    socket.emit("deleteGroup", group);
}

function getGroupList(){
    socket.emit("getGroup");
}

socket.on("returnAllGroup", function(getAllGroup){
    if(document.getElementById("group").value != ""){
    var countGroup = getAllGroup.split('\n').length;
        for (var i = 0; i < countGroup-1; i++) {
            if ((countGroup-1) == (i + 1)) {
                var groupText = getAllGroup.split('\n')[i];
                    document.getElementById("groupList").insertAdjacentHTML("beforeend", "<option>" + groupText + "</option>");
            }
        }
    } else {
    var countGroup = getAllGroup.split('\n').length;
        for (var i = 0; i < countGroup-1; i++) {
            var groupText = getAllGroup.split('\n')[i];
                document.getElementById("groupList").insertAdjacentHTML("beforeend", "<option>" + groupText + "</option>");
        }
    }
});