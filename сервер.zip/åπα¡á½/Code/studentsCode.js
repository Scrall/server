var socket = io.connect();

function addStudent(){
    name = document.getElementById("name").value;
        surname = document.getElementById("surname").value;
            Patronymic = document.getElementById("Patronymic").value;
                groupList = document.getElementById("groupList").value;
                    number = document.getElementById("number").value;
                        email = document.getElementById("email").value;
                            password = document.getElementById("password").value;
                                correct_password = document.getElementById("correct_password").value;
    socket.emit("addStudent", name, surname, Patronymic, groupList, number, email, password, correct_password);
        var FIO = surname + " " + name + " " + Patronymic;
            var group = groupList;
    document.getElementById("contForStudentID").insertAdjacentHTML("beforeend", 
    "<tr>" +
    "<th>" + group + "</th>" + 
    "<th>" + FIO + "</th>" + 
    "</tr>");
}

function getList(){
    socket.emit("getGroup");
    socket.emit("getStudents");
}

socket.on("returnAllGroup", function(getAllGroup){
    var countGroup = getAllGroup.split('\n').length;
        for (var i = 0; i < countGroup-1; i++) {
            var groupText = getAllGroup.split('\n')[i];
                document.getElementById("groupList").insertAdjacentHTML("beforeend", "<option>" + groupText + "</option>");
        }
});

var counterStudent = 0;

socket.on("returnStudents", function(student){
    var FIO = student.split('\n')[1] + " " + student.split('\n')[0] + " " + student.split('\n')[2];
    var group = student.split('\n')[3];
    document.getElementById("contForStudentID").insertAdjacentHTML("beforeend", 
    "<tr>" +
    "<th>" + group + "</th>" + 
    "<th>" + FIO + "</th>" + 
    "</tr>");
});

