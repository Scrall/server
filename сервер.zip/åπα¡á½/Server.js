var express = require('express');
var fs = require('fs');
const { emit } = require('process');
var app = express();
var server = require('http').createServer(app);
var io = require('socket.io')(server);

app.use(express.static(__dirname));

server.listen(5000);

app.get('/', function(Server, Client){
    Server.redirect(__dirname + "/index.html");
});

app.get('/group', function(req, res){
    res.sendFile(__dirname + '/group.html');
  });

app.use(express.static(__dirname + '/code'));
app.use(express.static(__dirname + '/Style'));

connections = [];

io.sockets.on('connection', function(socket) {
	connections.push(socket);

socket.on('disconnect', function(data) {
  	connections.splice(connections.indexOf(socket), 1);
    });

socket.on("addStudent", function(name, surname, Patronymic, groupList, number, email, password, correct_password){
    var text = name + "\n" + surname + "\n" + Patronymic + "\n" + groupList + "\n" + number + "\n" + email + "\n" + password + "\n" + correct_password;
        fs.writeFile("Students/" + groupList + " " + surname + " " + name + " " + Patronymic + " " + number, text, 'utf-8', function(error){
            if(error) throw error;
        });
    });

socket.on("addGroup", function(group){
        fs.appendFileSync("groups/groupList.list", group + "\n", "utf-8", function(error){
            if(error) throw error;
        });
        var getAllGroup = fs.readFileSync("groups/groupList.list").toString();
        socket.emit("returnAllGroup", getAllGroup);
    });

socket.on("changeGroup", function(group, oldGroup){
    var getAllGroup = fs.readFileSync("groups/groupList.list").toString();
        var changeGroup = getAllGroup.replace(oldGroup, group)
            fs.writeFile("groups/groupList.list", changeGroup, 'utf-8', function(error){
                if(error) throw error;
            });
    })

socket.on("deleteGroup", function(group){
    var getAllGroup = fs.readFileSync("groups/groupList.list").toString();
        var deleteGroup = getAllGroup.replace(group+"\n", "");
            fs.writeFile("groups/groupList.list", deleteGroup, 'utf-8', function(error){
                if(error) throw error;
            });
    });

socket.on("getGroup", function(){
        var getAllGroup = fs.readFileSync("groups/groupList.list").toString();
        socket.emit("returnAllGroup", getAllGroup);
    });

socket.on("getStudents", function(){
    fs.readdirSync(__dirname+"/Students").forEach(file => {
        var student = fs.readFileSync("Students/" + file).toString();
            socket.emit("returnStudents", student);
        });
    });
});

